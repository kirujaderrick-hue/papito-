package com.papito.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.SharedPreferences;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private LinearLayout page;
    private EditText pinInput, multiplierInput;
    private Spinner platformSpinner;
    private final ArrayList<Double> rounds = new ArrayList<>();
    private double balance = 1000.0;
    private TextView statsView, balanceView, statusView;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("papito_local", MODE_PRIVATE);
        showPinScreen();
    }

    private void base(String heading) {
        ScrollView scroll = new ScrollView(this);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(36, 34, 36, 36);
        page.setBackgroundColor(0xFFF4F6FA);
        scroll.addView(page);
        setContentView(scroll);
        TextView title = new TextView(this);
        title.setText(heading);
        title.setTextSize(28);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(0xFF14213D);
        page.addView(title);
        TextView sub = new TextView(this);
        sub.setText("Your personal Aviator practice tracker");
        sub.setTextSize(14);
        sub.setTextColor(0xFF526078);
        sub.setPadding(0, 6, 0, 22);
        page.addView(sub);
    }

    private TextView text(String value) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(16); t.setTextColor(0xFF172033);
        t.setPadding(0, 12, 0, 8); page.addView(t); return t;
    }

    private EditText edit(String hint, int type) {
        EditText e = new EditText(this);
        e.setSingleLine(true); e.setHint(hint); e.setInputType(type);
        e.setTextSize(17); e.setPadding(18, 12, 18, 12);
        e.setBackgroundColor(0xFFFFFFFF);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = 12; page.addView(e, lp); return e;
    }

    private Button button(String label, View.OnClickListener action) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false);
        b.setTextSize(15); b.setOnClickListener(action);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = 8; page.addView(b, lp); return b;
    }

    private void showPinScreen() {
        base("PAPITO");
        boolean exists = prefs.contains("pin_hash");
        text(exists ? "Enter your PIN to unlock Papito." : "Create a private 4–8 digit PIN.");
        pinInput = edit("4–8 digit PIN", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        statusView = text("");
        button(exists ? "Unlock Papito" : "Create PIN", v -> {
            String pin = pinInput.getText().toString();
            if (pin.length() < 4 || pin.length() > 8) { statusView.setText("PIN must contain 4 to 8 digits."); return; }
            String hash = sha256(pin);
            if (exists) {
                if (hash.equals(prefs.getString("pin_hash", ""))) showDashboard();
                else statusView.setText("Incorrect PIN. Try again.");
            } else {
                prefs.edit().putString("pin_hash", hash).apply();
                showDashboard();
            }
        });
        text("Your PIN hash is stored locally on this phone. Do not share your PIN.");
    }

    private String sha256(String value) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder();
            for (byte b : bytes) out.append(String.format(Locale.US, "%02x", b));
            return out.toString();
        } catch (Exception e) { return ""; }
    }

    private void showDashboard() {
        base("PAPITO");
        text("Platform");
        platformSpinner = new Spinner(this);
        String[] platforms = {"Betika", "Other platform"};
        platformSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, platforms));
        page.addView(platformSpinner);
        text("Completed Aviator multiplier");
        multiplierInput = edit("Example: 2.35", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        button("Save completed round", v -> saveRound());
        statsView = text("");
        updateStats();
        text("Virtual practice");
        balanceView = text("");
        updateBalance();
        text("Practice uses virtual money only. Starting balance: KSh 1,000. Stake: KSh 20.");
        button("Practice win (use multiplier above)", v -> practice(true));
        button("Practice loss (KSh 20)", v -> practice(false));
        button("Clear session round history", v -> { rounds.clear(); updateStats(); });
        text("Important: Papito does not connect to betting platforms, read live rounds, place real bets, or predict outcomes. Statistics describe only the rounds you enter.");
    }

    private Double enteredMultiplier() {
        try {
            double x = Double.parseDouble(multiplierInput.getText().toString().trim());
            return x > 0 ? x : null;
        } catch (Exception e) { return null; }
    }

    private void saveRound() {
        Double x = enteredMultiplier();
        if (x == null) { Toast.makeText(this, "Enter a valid multiplier above 0.", Toast.LENGTH_SHORT).show(); return; }
        rounds.add(x); updateStats();
        Toast.makeText(this, "Completed round saved for this session.", Toast.LENGTH_SHORT).show();
    }

    private void updateStats() {
        if (statsView == null) return;
        if (rounds.isEmpty()) { statsView.setText("Session statistics\nRounds: 0\nAverage: —\nMinimum: —\nMaximum: —\nRounds ≥ 2x: —"); return; }
        double sum = 0, min = Double.MAX_VALUE, max = 0; int two = 0;
        for (double x : rounds) { sum += x; min = Math.min(min, x); max = Math.max(max, x); if (x >= 2.0) two++; }
        statsView.setText(String.format(Locale.US,
            "Session statistics\\nRounds: %d\\nAverage: %.2fx\\nMinimum: %.2fx\\nMaximum: %.2fx\\nRounds ≥ 2x: %.1f%%",
            rounds.size(), sum / rounds.size(), min, max, 100.0 * two / rounds.size()));
    }

    private void updateBalance() {
        if (balanceView != null) balanceView.setText(String.format(Locale.US, "Virtual balance: KSh %,.2f", balance));
    }

    private void practice(boolean win) {
        if (balance < 20) { Toast.makeText(this, "Virtual balance is too low.", Toast.LENGTH_SHORT).show(); return; }
        if (win) {
            Double x = enteredMultiplier();
            if (x == null || x < 1.0) { Toast.makeText(this, "Enter a multiplier of at least 1.00x.", Toast.LENGTH_SHORT).show(); return; }
            balance += 20.0 * (x - 1.0);
        } else balance -= 20.0;
        updateBalance();
        Toast.makeText(this, "Virtual practice updated. No real money used.", Toast.LENGTH_SHORT).show();
    }
}
